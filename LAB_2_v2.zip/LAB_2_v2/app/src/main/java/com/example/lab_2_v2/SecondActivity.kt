package com.example.lab_2_v2

import android.R.attr.x
import android.R.attr.y
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.opengl.ETC1.getHeight
import android.opengl.ETC1.getWidth
import android.os.Bundle
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class SecondActivity : AppCompatActivity() {

    bitmap
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val myCanvasView = MyCanvasView(this)
        myCanvasView.systemUiVisibility = SYSTEM_UI_FLAG_FULLSCREEN
        myCanvasView.contentDescription = getString(R.string.canvasContentDescription)
        setContentView(myCanvasView)
        myCanvasView.extraBitmap
    }
    override fun onBackPressed() {
        val resultIntent = Intent()
        resultIntent.putExtra("Result", myCanvasView.extraBitmap)
        setResult(RESULT_OK, resultIntent)
        finish()
    }
}